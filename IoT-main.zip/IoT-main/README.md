
# IoT
## conteúdos que eu farei da matéria

![Captura de tela 2024-08-23 220024](https://github.com/user-attachments/assets/34ada3e7-4037-45b0-b0b1-5fbc6ef53993)
